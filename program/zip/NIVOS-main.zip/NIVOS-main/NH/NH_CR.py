import os
import time
from colorama import Fore,Back,Style
import socket
import requests
class bcolors:
    OK = '\033[92m' 
    a = '\033[93m' 
    FAIL = '\033[91m' 
    RESET = '\033[0m' 
    #TheSadError Repo
os.system("clear")
os.system("figlet Error | lolcat")
print(f"{bcolors.FAIL}This Tool Created By Error")
print(f"{bcolors.FAIL}Github  : https://github.com/TheSadError ")
print(f"{bcolors.FAIL}Discord : err0r#4018")
print(f"{bcolors.FAIL}Website : https://thesaderror.github.io/NIVOSITE/")
print(f"{bcolors.FAIL}Gmail   : syntaxerrorses@gmail.com")
print("[INFO]  : ")
print("""
NIVOS is a python tool that allows you to scan deeply, 
crack wifi, see people on your network. 
It applies to all linux operating systems. 
And it is improving every day, new packages are added.
""")

print("[DEEP INFO] NIVOS Tool created by Error. Tool is still upgrading...")

print(f"""{bcolors.OK}
Required Packets :

bettercap
aircrack-ng
scapy
pyfiglet
os
php
hostapd
google
youtube
urllib3
platform
gcc
python3
lolcat
colorama
cowpatty
pandas
tld
nmap
""")

print(f"{bcolors.FAIL}Please Dont Forget To Star NIVOS REPO : https://github.com/TheSadError/NIVOS")