
## Raymond Tool
  ![Programmer and Problems solver](https://raw.githubusercontent.com/hamza07-w/raymond/main/files/1.png)
  
## How to use
```
git clone https://github.com/hamza07-w/raymond.git
```
```
cd raymond
```
#### Windows
```
python raymond(win).py - u <web applicaion domain>
```

#### Linux
```
python3 raymond(lin).py - u <web applicaion domain>
```

## About
  The Name Raymond Red Reddington is a main character in the NBC series The Blacklist, So that you can say this tool can search and take any information about the target website from many resources just like was raymond do.. and in the next version of tool, I will add the option of multiscan that allow you scan black list targets at the same time.
  
## LICENCE
[MIT](https://github.com/hamza07-w/raymond/blob/main/LICENSE)
